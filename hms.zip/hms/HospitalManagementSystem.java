package hms;
import java.io.InputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;
import java.util.Scanner;

public class HospitalManagementSystem {

	private static String url;
	private static String username;
	private static String password;
	
	private static void loadDatabaseCredentials() {
		Properties properties = new Properties();
		try (InputStream input = HospitalManagementSystem.class.getResourceAsStream("db.properties")) {
			if (input != null) {
				properties.load(input);
				url = properties.getProperty("db.url");
				username = properties.getProperty("db.username");
				password = properties.getProperty("db.password");
			} else {
				System.err.println("Error: db.properties file not found in the package directory!");
				System.exit(1);
			}
		} catch (IOException e) {
			System.err.println("Error reading db.properties file!");
			e.printStackTrace();
			System.exit(1);
		}
	}

	public static void main(String[] args) {
		loadDatabaseCredentials();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
	Scanner scanner=new Scanner(System.in);
	try
	{
		Connection connection=DriverManager.getConnection(url,username,password);
		Patient patient=new Patient(connection,scanner);
		Doctor doctor=new Doctor(connection,scanner);
	while(true) {
		System.out.println("Hospital Management System");
		System.out.println("1.Add Patient");
		System.out.println("2.View Patient");
		System.out.println("3.Add Doctors");
		System.out.println("4.View Doctors");
		System.out.println("5.Book Appointment");
		System.out.println("6.Exit");
		System.out.println("Please Enter your choice");
		
		int choice=scanner.nextInt();
		switch(choice) {
		case 1:
			//Add Patient
			patient.addPatient();
			System.out.println();
			break;
		case 2:
			//View Patient
			patient.viewPatients();
			System.out.println();
			break;
		case 3:
			doctor.addDoctor();
			System.out.println();
			break;
		case 4:
			//View doctors
			doctor.viewDoctors();
			System.out.println();
			break;
		case 5:
			//Book Appointment
			bookAppointment(patient,doctor,connection,scanner);
			System.out.println();
			break;
		case 6:
			System.out.println("Thank you! for using hospital management system");
			return;
		default:
			System.out.println("Please Enter Valid Input");
		}
	}
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	
	}	
	public static void bookAppointment(Patient patient,Doctor doctor,Connection connection,Scanner scanner)
	{
		System.out.println("Please Enter Patient ID:");
		int patientID=scanner.nextInt();
		System.out.println("Please enter Doctor ID:");
		int doctorID=scanner.nextInt();
		System.out.println("Please enter appointment date(YYYY-MM-DD");
		String appointmentDate=scanner.next();
		
		if(patient.getPatientById(patientID)&& doctor.getDoctorByID(doctorID))
		{
			if(checkDoctorAvailability(doctorID,appointmentDate,connection)) {
				String appointmentQuery="INSERT INTO appointments (patients_id,doctor_id,appointment_date) values (?,?,?)";
				try {
					PreparedStatement preparedStatement=connection.prepareStatement(appointmentQuery);
					preparedStatement.setInt(1,patientID);
					preparedStatement.setInt(2,doctorID);
					preparedStatement.setString(3,appointmentDate);
				int rowsAffected=preparedStatement.executeUpdate();
				if(rowsAffected>0)
				{
					System.out.println("Appointment Booked");
				}
				else {
					System.out.println("Appointment could not ne booked");
				}
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
				else {
					System.out.println("Doctor not available on this date!!");
				}
			}
				else {
					System.out.println("Either doctor or patient doesn't exist!!!");
				}
			}
	public static boolean checkDoctorAvailability(int doctorID,String appointmentDate,Connection connection) {
		//count(*) : getting the rows which matches the particular criteria
		String query="SELECT COUNT(*) FROM appointments WHERE doctor_id=? AND appointment_date = ?";
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setInt(1, doctorID);
			preparedStatement.setString(2, appointmentDate);
			ResultSet resultset=preparedStatement.executeQuery();
			if(resultset.next()) {
				int count=resultset.getInt(1);
				if(count==0) {
					return true;
				}
				else {
					return false;
				}
			}
			
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
}