package hms;

import java.sql.*; //for managing all the sql connections and use the sql packages
import java.util.Scanner; //to take the user input 

public class Patient {

private Connection connection;
private Scanner scanner;

public Patient(Connection connection,Scanner scanner)
{
	
	this.connection=connection;
	this.scanner=scanner;
}
//Method to add Patients
public void addPatient() {
	System.out.println("Enter patient's Name:");
	String name=scanner.next();
	System.out.println("Enter patient's Age:");
	int age=scanner.nextInt();
	System.out.println("Enter Patient's Gender");
	String gender=scanner.next();
//To insert the input values to the database we use the below steps....
// ? ->indicates we use preparedStatements and ? refers to that we dont know what values you will enter
	try {
		String Query="Insert into patients(name,age,gender) values (?,?,?)";
		PreparedStatement preparedStatement=connection.prepareStatement(Query);
		preparedStatement.setString(1,name);//1 indicates 1st question mark
		preparedStatement.setInt(2,age); //2 indicates 2nd question mark
		preparedStatement.setString(3,gender); //3 indicates 3rd question mark
		
		int affectedRows=preparedStatement.executeUpdate(); //How do you know you have inserted the data into database ?? Ans:prepraedstatement.executeUpdate()-every time a new value is added the row value will be updated to 1
		
		if(affectedRows>0)
		{
			System.out.println("Patient Added Successfully");
		}
		else {
			System.out.println("Failed to add Patient!!");
		}
		
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	
}

//Method to view Patients
public void viewPatients() {
	String query="select * from patients"; //to view patient we write this query
	try {
		PreparedStatement preparedStatement=connection.prepareStatement(query);
		ResultSet resultset=preparedStatement.executeQuery(); //to get the information from the database and show it to the client ,such data we store it in the resultset
		System.out.println("Patients:	");
		System.out.println("+-------------+---------------------+------+----------+");
		System.out.println("| Patient ID  | Name                | Age  | Gender   |");
		System.out.println("+-------------+---------------------+----- +----------+");
		while(resultset.next()) {//resultset.next()-as long as you have information the while loop will be running {
			int id=resultset.getInt("id");
			String name=resultset.getString("name");
			int age=resultset.getInt("age");
			String gender=resultset.getString("gender");
			
			System.out.printf("|%-13s|%-21s|%-6s|%-10s|\n",id,name,age,gender); //here we use print f because f stands for formatting (%13s,%21s,%6s etc).
			System.out.println("+-------------+---------------------+------+----------+");
		}
	}
catch(SQLException e) {
	e.printStackTrace();
}
}

public boolean getPatientById(int id) {
	String query="select * from patients where ID = ?";
	try {
		PreparedStatement preparedstatement =connection.prepareStatement(query);
		preparedstatement.setInt(1, id);
		ResultSet resultset=preparedstatement.executeQuery();
		if(resultset.next())
		{
			return true;
		}
		else {
			return false;
		}
	}
	catch(SQLException e) {
		e.printStackTrace();
	}
	return false;
}

}
