package hms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;



public class Doctor {

	
	private Connection connection;
	private Scanner scanner;
	
	public Doctor(Connection connection,Scanner scanner)
	{
		
		this.connection = connection;
		this.scanner=scanner;
		
		
	}
	
	public void addDoctor() {
		System.out.println("Enter Doctor's Name:");
		String name=scanner.next();
		System.out.println("Enter Doctor's Specialization");
		String specialization=scanner.next();
	//To insert the input values to the database we use the below steps....
	// ? ->indicates we use preparedStatements and ? refers to that we dont know what values you will enter
		try {
			String Query="Insert into doctors(name,specialization) values (?,?)";
			PreparedStatement preparedStatement=connection.prepareStatement(Query);
			preparedStatement.setString(1,name);//1 indicates 1st question mark
			preparedStatement.setString(2,specialization); //3 indicates 3rd question mark
			
			int affectedRows=preparedStatement.executeUpdate(); //How do you know you have inserted the data into database ?? Ans:prepraedstatement.executeUpdate()-every time a new value is added the row value will be updated to 1
			
			if(affectedRows>0)
			{
				System.out.println("Doctor Added Successfully");
			}
			else {
				System.out.println("Failed to add Doctor!!");
			}
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
	}
	//Method to viewPatients
	public void viewDoctors()
	{
		String query = "select * from doctors";
		
		try {
			
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultset = preparedStatement.executeQuery();
			
			System.out.println("Doctors: ");
			System.out.println("+-------------+---------------------+------+----------+");
			System.out.println(" | Doctor ID  | Name                | Specialization  |");
			System.out.println("+-------------+---------------------+------+----------+");
			
			while(resultset.next())
			{
				
				int id = resultset.getInt("id");
				String name = resultset.getString("name");
				//int age = resultset.getInt("age");
				String specilization = resultset.getString("specialization");
				
				System.out.printf("|%-15s|%-20s|%-18s|\n",id,name,specilization);
				System.out.println("+-------------+---------------------+------+----------+");
			}
			
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public boolean getDoctorByID(int id)
	{
		String query = "select * from doctors where ID = ?";
		
		try {
			
			PreparedStatement preparedstatement = connection.prepareStatement(query);
			preparedstatement.setInt(1,id);
			ResultSet resultset = preparedstatement.executeQuery();
			if(resultset.next())
			{
				return true;
				}
			else {
				return false;
				}
			
		}catch(SQLException e) {e.printStackTrace();}
		return false;
	}


	
	}